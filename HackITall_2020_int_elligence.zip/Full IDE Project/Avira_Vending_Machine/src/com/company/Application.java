package com.company;

public class Application {

    public static void run(){
        GUI appGui = generateGui();
        appGui.getFrame().setVisible(true);
        //new DataForm(new GUI.UserData(null,null,null,null,null));
    }

    public static GUI generateGui(){
        return new GUI();
    }
}

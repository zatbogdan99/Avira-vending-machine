package com.company;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DataForm extends JFrame implements ActionListener {

    private JLabel emailLabel;
    private JLabel firstNameLabel;
    private JLabel lastNameLabel;
    private JLabel addressLabel;
    private JLabel reasonLabel;

    private JTextField emailTextField;
    private JTextField firstNameTextField;
    private JTextField lastNameTextField;
    private JTextField addressTextField;
    private JTextField reasonTextField;

    private JButton submitButton;

    private JPanel mainPanel;
    private JPanel emailLabelPanel;
    private JPanel emailTextFieldPanel;
    private JPanel firstNameLabelPanel;
    private JPanel firstNameTextFieldPanel;
    private JPanel lastNameLabelPanel;
    private JPanel lastNameTextFieldPanel;
    private JPanel addressLabelPanel;
    private JPanel addressTextFieldPanel;
    private JPanel reasonLabelPanel;
    private JPanel reasonTextFieldPanel;
    private JPanel submitButtonPanel;

    private final int LABEL_TEXT_SIZE = 15;
    private final int INPUT_FIELDS_SIZE = 40;

    private GUI.UserData userData;
    private AviraProduct product;
    private PaymentSolution.PAYMENT paymentType;

    public DataForm(AviraProduct product,
                    PaymentSolution.PAYMENT paymentType){
        this.userData = new GUI.UserData();
        this.product = product;
        this.paymentType = paymentType;

        initializeComponents();
        setSize(500,500);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        centerFrame();
        setTitle("Data Form");
        setVisible(true);
    }

    private void initializeComponents(){
        initializeLabels();
        initializeTextFields();
        initializeButton();
        initializePanels();
        addComponentsToPanels();
    }

    private void initializeLabels(){
        emailLabel =new JLabel("Email:");
        firstNameLabel = new JLabel("First Name:");
        lastNameLabel = new JLabel("Last Name:");
        addressLabel = new JLabel("Address:");
        reasonLabel = new JLabel("Tell us why you chose this product:");

        Font font = new Font("SansSerif", Font.PLAIN,LABEL_TEXT_SIZE);

        emailLabel.setFont(font);
        firstNameLabel.setFont(font);
        lastNameLabel.setFont(font);
        addressLabel.setFont(font);
        reasonLabel.setFont(font);
    }

    private void initializeTextFields(){
        emailTextField =new JTextField(INPUT_FIELDS_SIZE);
        firstNameTextField = new JTextField(INPUT_FIELDS_SIZE);
        lastNameTextField = new JTextField(INPUT_FIELDS_SIZE);
        addressTextField = new JTextField(INPUT_FIELDS_SIZE);
        reasonTextField = new JTextField(INPUT_FIELDS_SIZE);

        Font font = new Font("SansSerif", Font.PLAIN,13);

        emailTextField.setFont(font);
        firstNameTextField.setFont(font);
        lastNameTextField.setFont(font);
        addressTextField.setFont(font);
        reasonTextField.setFont(font);

        emailTextField.setBorder(BorderFactory.createEmptyBorder(3,10,3,10));
        firstNameTextField.setBorder(BorderFactory.createEmptyBorder(3,10,3,10));
        lastNameTextField.setBorder(BorderFactory.createEmptyBorder(3,10,3,10));
        addressTextField.setBorder(BorderFactory.createEmptyBorder(3,10,3,10));
        reasonTextField.setBorder(BorderFactory.createEmptyBorder(3,10,3,10));

    }

    private void initializeButton(){
        submitButton = new JButton("Submit");
        submitButton.setFocusPainted(false);
        submitButton.addActionListener(this);
    }

    private void initializePanels(){
        mainPanel = new JPanel();
        emailLabelPanel = new JPanel();
        emailTextFieldPanel = new JPanel();
        firstNameLabelPanel = new JPanel();
        firstNameTextFieldPanel = new JPanel();
        lastNameLabelPanel = new JPanel();
        lastNameTextFieldPanel = new JPanel();
        addressLabelPanel = new JPanel();
        addressTextFieldPanel = new JPanel();
        reasonLabelPanel = new JPanel();
        reasonTextFieldPanel = new JPanel();
        submitButtonPanel = new JPanel();

        mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));

        emailLabelPanel.setBorder(new EmptyBorder(20,10,0,20));
        emailTextFieldPanel.setBorder(new EmptyBorder(0,10,10,20));
        firstNameLabelPanel.setBorder(new EmptyBorder(0,10,0,20));
        firstNameTextFieldPanel.setBorder(new EmptyBorder(0,10,10,20));
        lastNameLabelPanel.setBorder(new EmptyBorder(0,10,0,20));
        lastNameTextFieldPanel.setBorder(new EmptyBorder(0,10,10,20));
        addressLabelPanel.setBorder(new EmptyBorder(0,10,0,20));
        addressTextFieldPanel.setBorder(new EmptyBorder(0,10,10,20));
        reasonLabelPanel.setBorder(new EmptyBorder(0,10,0,20));
        reasonTextFieldPanel.setBorder(new EmptyBorder(0,10,10,20));


        this.add(mainPanel);
        mainPanel.add(emailLabelPanel);
        mainPanel.add(emailTextFieldPanel);
        mainPanel.add(firstNameLabelPanel);
        mainPanel.add(firstNameTextFieldPanel);
        mainPanel.add(lastNameLabelPanel);
        mainPanel.add(lastNameTextFieldPanel);
        mainPanel.add(addressLabelPanel);
        mainPanel.add(addressTextFieldPanel);
        mainPanel.add(reasonLabelPanel);
        mainPanel.add(reasonTextFieldPanel);
        mainPanel.add(submitButtonPanel);
    }

    private void addComponentsToPanels(){
        emailLabelPanel.add(emailLabel);
        emailTextFieldPanel.add(emailTextField);
        firstNameLabelPanel.add(firstNameLabel);
        firstNameTextFieldPanel.add(firstNameTextField);
        lastNameTextFieldPanel.add(lastNameTextField);
        lastNameLabelPanel.add(lastNameLabel);
        addressTextFieldPanel.add(addressTextField);
        addressLabelPanel.add(addressLabel);
        reasonTextFieldPanel.add(reasonTextField);
        reasonLabelPanel.add(reasonLabel);
        submitButtonPanel.add(submitButton);
    }

    private void centerFrame(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == submitButton){

            // basic checks for the given input
            if(emailTextField.getText() == null || emailTextField.getText().isEmpty()){
                    JOptionPane.showMessageDialog(this,"Invalid email");
                    return;
            }
            if(emailTextField.getText().contains("@") == false){
                JOptionPane.showMessageDialog(this,"Invalid email");
                return;
            }
            if(firstNameTextField.getText() == null || firstNameTextField.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"Invalid first name");
                return;
            }
            if(lastNameTextField.getText() == null || lastNameTextField.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"Invalid last name");
                return;
            }
            if(addressTextField.getText() == null || addressTextField.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"Invalid address");
                return;
            }

            userData.setEmail(emailTextField.getText());
            userData.setFirstName(firstNameTextField.getText());
            userData.setLastName(lastNameTextField.getText());
            userData.setAddress(addressTextField.getText());
            userData.setReason(reasonTextField.getText());
            userData.setProductName(product.getName());
            userData.complete = true;
            JOptionPane.showMessageDialog(this,"Form submitted");


            // permforming the chosen type of payment method
            if(paymentType == PaymentSolution.PAYMENT.CARD){
                if(PaymentSolution.paymentCard(product,this))
                    sendUserData(userData);
                GUI.PERFORMING_TRANSACTION = false;
            }
            if(paymentType == PaymentSolution.PAYMENT.CASH){
                if(PaymentSolution.paymentCash(product,this))
                    sendUserData(userData);
                GUI.PERFORMING_TRANSACTION = false;
            }

            setVisible(false);
            dispose();


        }else{
            JOptionPane.showMessageDialog(this,"Invalid input");
        }
    }


    //dummy method for sending the user data given in the form to the server
    private void sendUserData(GUI.UserData data){
        //sending user data to server for statistics...
        System.out.println("Sending data to server for analytics...");
    }
}

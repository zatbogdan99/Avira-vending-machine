package com.company;

import javax.persistence.criteria.CriteriaBuilder;
import javax.swing.*;


public class PaymentSolution {

    public enum PAYMENT{
        CASH,
        CARD
    }

    public static boolean paymentCash(AviraProduct product, JFrame frame){
        if(product.getStock() <= 0){
            JOptionPane.showMessageDialog(frame,"Out of stock");
            return false;
        }

        double paid =0;
        while(paid < product.getPrice()) {
            StringBuilder sb = new StringBuilder();
            sb.append("Introduce cash:\n");
            sb.append("Current amount: " + paid + "$");
            sb.append(" from " + product.getPrice() + "$");
            String givenSum = JOptionPane.showInputDialog(frame, sb.toString(),"Payment",1);
            paid += (givenSum!=null)?
                    Integer.parseInt(givenSum)
                    : 0;
            if(givenSum == null){
                return false;
            }
        }

        JOptionPane.showMessageDialog(frame, "Succesful transaction!\nYour change: "+(paid - product.getPrice())+"$");
        if(paid - product.getPrice() > 0)
            JOptionPane.showMessageDialog(frame,"Please pick up your change!");
        return product.purchase(1);
    }

    public static boolean paymentCard(AviraProduct product, JFrame frame){
        if(product.getStock() <= 0){
            System.out.println("Failed transaction - out of stock");
            JOptionPane.showMessageDialog(frame, "Failed transaction - out of stock");
            return false;
        }
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Introduce PIN:");
        JPasswordField pin = new JPasswordField(10);
        panel.add(label);
        panel.add(pin);
        String[] options = new String[]{"OK", "Cancel"};
        int option = JOptionPane.showOptionDialog(null, panel, "Bank transaction",
                JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);

        if(option == 0)
        {
            char[] a = pin.getPassword();
            System.out.print(a);
            System.out.print("\n");
            requestPaymentServiceConfirmaton();
            JOptionPane.showMessageDialog(frame, "Succesful transaction!\nPick up your product!");
            return product.purchase(1);
        }else{
            System.out.println("Failed transaction");
            JOptionPane.showMessageDialog(frame, "Failed transaction");
            return false;
        }
    }

    private static void requestPaymentServiceConfirmaton(){
        // checking card payment valid
        System.out.println("Card payment valid");
    }
}

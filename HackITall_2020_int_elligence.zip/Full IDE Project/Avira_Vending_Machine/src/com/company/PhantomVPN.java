package com.company;

import java.nio.charset.Charset;
import java.util.Random;

public class PhantomVPN extends AviraProduct {

    public PhantomVPN(int initialStock) {
        super("Phantom VPN", initialStock, 50);
    }

}

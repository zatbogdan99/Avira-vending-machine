Run with Makefile
-> open ./Sources folder
-> check environment variables java and javac
	-> current configuration: java -v  "1.8.0_231" , javac -v "1.8.0_221"
-> run "make" for building the .class files
-> run "make run" for running the application
-> run "make clean" for deleting the .class files



Run .jar application
-> open ./Project_Jar folder
-> double-click the .jar application



View the entire Java project
-> open ./FUll\ IDE\ Project folder with IntelliJ or Eclipse


(Product images might not render in the app depending on the platform, we attached screenshots to showcase the full design)

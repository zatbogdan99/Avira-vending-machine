public class AntivirusPro extends AviraProduct {

    public AntivirusPro(int initialStock) {
        super("Antivirus PRO", initialStock, 35);
    }
}

public class AviraPrime extends AviraProduct{

    public AviraPrime(int initialStock) {
        super("Avira Prime", initialStock, 75);
    }
}

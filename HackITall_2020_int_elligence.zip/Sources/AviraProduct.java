// common base class for any Avira product
public abstract class AviraProduct {

    public final static int STOCK_LIMIT = 10;

    private int stock;
    private String productName;
    private double price;

    public AviraProduct(String productName,
                        int initialStock,
                        double price){
        this.productName = productName;
        this.stock = initialStock;
        this.price = price;
    }

    // adds new count of products if argument valid, cannot overflow stock limit
    public void add(int newProducts){
        if(newProducts <= 0) return;
        this.stock = Math.min(this.stock + newProducts, STOCK_LIMIT);
    }

    // returns true if there are sufficient available products to purchase, else false
    public boolean purchase(int count){
        if(count > this.stock){
            System.out.println("[" + this.productName+"] Unable to purchase "
                    + count + "| only " + this.stock + " remaining");
            return false;
        }
        this.stock -= count;
        return true;
    }

    public String getName(){return this.productName;}
    public int getStock(){return this.stock;}
    public double getPrice(){return this.price;}

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("[" + this.getName() + "] ");
        sb.append("stock: ");
        sb.append(this.getStock());
        return sb.toString();
    }

}

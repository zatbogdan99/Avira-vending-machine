import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class GUI {
    private JFrame frame;
    private JPanel gridPanel;
    private JButton[] productButtons;
    private JButton settings;
    private JLabel label1;
    private ImageIcon[] icons;
    private ArrayList<AviraProduct> aviraProducts = new ArrayList<>();

    private final int FRAME_WIDTH = 650;
    private final int FRAME_HEIGHT = 800;
    private final int GRID_ROWS = 3;
    private final int GRID_COLUMNS = 2;
    private final int GRID_WIDTH = 650;
    private final int GRID_HEIGHT = 580;
    private final int BUTTON_TEXT_FONT_SIZE = 15;
    private final String ACTION_LABEL_TEXT = "Please choose your product:";

    public static boolean PERFORMING_TRANSACTION = false;

    public GUI(){
        injectProductsList();
        initializeIcons();
        initializeFrame();
        initializeListeners();
    }

    private void injectProductsList(){
        aviraProducts.add(new AviraPrime(AviraProduct.STOCK_LIMIT));
        aviraProducts.add(new AntivirusPro(AviraProduct.STOCK_LIMIT));
        aviraProducts.add(new PhantomVPN(AviraProduct.STOCK_LIMIT));
        aviraProducts.add(new PasswordManager(AviraProduct.STOCK_LIMIT));
        aviraProducts.add(new Optimizer(AviraProduct.STOCK_LIMIT));
        aviraProducts.add(new SystemSpeedup(AviraProduct.STOCK_LIMIT));
    }

    private void initializeIcons(){
        icons = new ImageIcon[aviraProducts.size()];
        for(int i = 0; i < icons.length; i++){
            StringBuilder pathBuilder= new StringBuilder("resources/img");
            pathBuilder.append(i);
            pathBuilder.append(".png");
            icons[i] = new ImageIcon(pathBuilder.toString());
        }
    }

    private void initializeFrame(){
        frame = new JFrame("Avira Vending Machine");
        frame.setBounds(1000, 150, FRAME_WIDTH, FRAME_HEIGHT);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel contentPane = new JPanel(null);
        gridPanel = new JPanel(new GridLayout(GRID_ROWS,GRID_COLUMNS));
        gridPanel.setBounds(0,200,GRID_WIDTH,GRID_HEIGHT);

        initializeButtons(gridPanel);
        contentPane.add(gridPanel);

        label1 = new JLabel(ACTION_LABEL_TEXT,SwingConstants.CENTER);
        label1.setFont(new Font("SansSerif",Font.BOLD,30));
        label1.setBounds(0,50, 500, 50);
        contentPane.add(label1);

        settings = new JButton("S");
        settings.setBounds(0, 0, 0,0);
        settings.setMnemonic(KeyEvent.VK_F1);
        contentPane.add(settings);

        frame.add(contentPane);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
    }

    private void initializeButtons(JPanel panel){
        productButtons = new JButton[aviraProducts.size()];
        for(int i = 0; i < productButtons.length; i++){
            productButtons[i] = new JButton("",icons[i]);
            productButtons[i].setHorizontalTextPosition(SwingConstants.RIGHT);
            productButtons[i].setForeground(Color.BLACK);
            productButtons[i].setBackground(Color.WHITE);
            productButtons[i].setFont(new Font("SansSerif",Font.BOLD,BUTTON_TEXT_FONT_SIZE));
            StringBuilder nameBuilder = new StringBuilder();
            nameBuilder.append(aviraProducts.get(i).getName());
            nameBuilder.append(" - ");
            nameBuilder.append(aviraProducts.get(i).getPrice() + "$");
            productButtons[i].setText(nameBuilder.toString());
            if(panel != null) panel.add(productButtons[i]);
        }
    }

    private void initializeListeners(){
        for(int i=0;i<aviraProducts.size();i++) {
            int j=i;
            productButtons[i].addActionListener(
                    new ActionListener() {
                         String[] options= {"Cash","Card","Anulare"};

                         @Override
                         public void actionPerformed(ActionEvent e) {
                             if(GUI.PERFORMING_TRANSACTION)
                                 return;
                             GUI.PERFORMING_TRANSACTION = true;

                             if(aviraProducts.get(j).getStock()>0) {
                                int n = JOptionPane.showOptionDialog(frame, "Choose your payment method:\nTotal cost: "+aviraProducts.get(j).getPrice()+"$","Payment",
                                JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,
                                null,options,options[2]);
                                 if(n==0) {
                                     new DataForm(aviraProducts.get(j), PaymentSolution.PAYMENT.CASH);
                                 }
                                 if(n==1) {
                                    new DataForm(aviraProducts.get(j), PaymentSolution.PAYMENT.CARD);
                                 }
                                 GUI.PERFORMING_TRANSACTION = false;
                             }
                             else{
                                 JOptionPane.showMessageDialog(frame, "This product is out of stock!");
                                 GUI.PERFORMING_TRANSACTION = false;
                             }
                         }
                    }
            );
        }
        settings.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String[] options= {"Add product","Fill stock","Cancel"};
                int n = JOptionPane.showOptionDialog(frame, "Setting", "Settings", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.DEFAULT_OPTION, null, options, options[2]);
                if(n==0) {
                    String[] possibilities = new String[aviraProducts.size()];
                    for(int i = 0; i < possibilities.length; i++)
                        possibilities[i] = aviraProducts.get(i).getName();

                    String s= (String)JOptionPane.showInputDialog(frame, "Choose product", "Settings", JOptionPane.PLAIN_MESSAGE, null,possibilities,possibilities[0]);
                    String amountString = JOptionPane.showInputDialog(frame,
                            "Introduce the amount:","Settings",1);
                   	
                   	try{
                   		if(amountString!=null){
                    	int amount = Integer.parseInt(amountString);
                    	for(int i = 0; i < aviraProducts.size(); i++)
                        if(s.equals(aviraProducts.get(i).getName()))
                            aviraProducts.get(i).add(amount);
                    	}
                   	}catch(NumberFormatException ex){
                   		JOptionPane.showMessageDialog(frame,"Invalid number");
                   	}
                   
                   
                    showStock();

                }
                if(n==1) {
                    for(int i=0;i<aviraProducts.size();i++) {
                        aviraProducts.get(i).add(AviraProduct.STOCK_LIMIT);
                    }
                    showStock();
                }
            }
        });

    }

    public void showStock(){
        System.out.println("\nShowing curret stock: ");
        for(int i = 0; i < aviraProducts.size(); i++)
            System.out.println(aviraProducts.get(i).toString());
        System.out.println();
    }

    public JFrame getFrame(){return this.frame;}

    public static class UserData{
        private String firstName;
        private String lastName;
        private String email;
        private String address;
        private String reason;

        public boolean complete;

        public UserData(){
            this(null,null,null,null,null);
        }

        public UserData(String firstName,
                        String lastName,
                        String email,
                        String address,
                        String reason){
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.address = address;
            this.reason = reason;
            this.complete = false;
        }
        public String getFirstName(){return this.firstName;}
        public String getLastName(){return this.lastName;}
        public String getEmail(){return this.email;}
        public String getAddress(){return this.address;}
        public String getReason(){return this.reason;}

        public void setEmail(String email){this.email = email;}
        public void setFirstName(String firstName){this.firstName = firstName;}
        public void setLastName(String lastName){this.lastName = lastName;}
        public void setAddress(String address){this.address = address;}
        public void setReason(String reason){this.reason = reason;}
    }
}

public class Optimizer extends AviraProduct {

    public Optimizer(int initialStock) {
        super("Optimizer", initialStock, 10);
    }
}

public class PasswordManager extends AviraProduct {

    public PasswordManager(int initialStock) {
        super("Password Manager", initialStock, 20);
    }
}

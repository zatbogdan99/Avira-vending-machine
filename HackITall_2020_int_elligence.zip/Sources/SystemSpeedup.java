public class SystemSpeedup extends AviraProduct {

    public SystemSpeedup(int initialStock) {
        super("System Speedup", initialStock, 25);
    }
}
